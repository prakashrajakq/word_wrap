<?php
$template = $_GET['template'] ?? '';
$path = "templates/" . basename($template);

if (file_exists($path)) {
    echo file_get_contents($path);
} else {
    http_response_code(404);
    echo "Template not found.";
}