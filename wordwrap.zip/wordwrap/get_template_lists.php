<?php
$templates = array_diff(scandir('templates'), ['.', '..']);
echo json_encode(array_values($templates));