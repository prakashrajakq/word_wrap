<?php
//Get template and content from editor
$template = $_POST['filename'] ?? '';
$content = $_POST['content'] ?? '';

$path = "templates/" . basename($template);

if (!empty($template) && file_exists($path)) {
    file_put_contents($path, $content);
    echo "Template saved successfully.";
} else {
    echo "Failed to save template.";
}
